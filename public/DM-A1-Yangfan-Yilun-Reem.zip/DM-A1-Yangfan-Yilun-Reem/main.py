"""
Assignment 1, Data Mining
Group members:
- Yangfan Chen (5194652),
- Yinglun Pu (8023042),
- Reem Najjar (6952011)
"""
import numpy as np
from multiprocessing import Pool, Manager


# For consistency among teammates:
# np.random.seed(42)

def tree_grow(x, y, nmin: int, minleaf: int, nfeat: int) -> 'Node':
    """
    Function Name: tree_grow

    Grow a decision tree recursively.

    Parameters:
    - x (list[list[int]] or np.ndarray): Feature matrix.
    - y (list[int] or np.ndarray): Target vector.
    - nmin (int): Minimum number of samples required to split a node.
    - minleaf (int): Minimum number of samples required in a leaf.
    - nfeat (int): Number of features to consider when looking for the best split.

    Returns:
    - Node: The root node of the decision tree.
    """
    _x = x if isinstance(x, np.ndarray) else np.array(x)
    _y = y if isinstance(y, np.ndarray) else np.array(y)

    classification = 1 if np.sum(_y) > len(y) / 2 else 0
    if len(_y) < nmin or impurity(_y) <= 0:
        return Node().set_leaf(classification)

    best_split_index, best_split_value = best_split(_x, _y, minleaf)
    if best_split_index is None:
        return Node().set_leaf(classification)

    left_indices = np.where(_x[:, best_split_index] <= best_split_value)[0]
    right_indices = np.where(_x[:, best_split_index] > best_split_value)[0]

    return Node().set_split(
        best_split_index,
        best_split_value,
        left=tree_grow(_x[left_indices], _y[left_indices], nmin, minleaf, nfeat),
        right=tree_grow(_x[right_indices], _y[right_indices], nmin, minleaf, nfeat),
    )


def tree_pred(x, tr: 'Node') -> int:
    """
    Function Name: tree_pred

    Predict the class of a sample using the decision tree.

    Parameters:
    - x (list[int] or np.ndarray): Feature vector for a single sample.
    - tr (Node): The root node of the decision tree.

    Returns:
    - int: Predicted class label.
    """
    current_node = tr
    while not current_node.is_leaf:
        if x[current_node.split_index] <= current_node.split_value:
            current_node = current_node.left
        else:
            current_node = current_node.right
    return current_node.classification


def tree_grow_b(x, y, nmin: int, minleaf: int, nfeat: int, m: int):
    """
    Function Name: tree_grow_b

    Grow multiple trees using bootstrap samples for random.

    Parameters:
    - x (np.ndarray): Feature matrix.
    - y (np.ndarray): Target vector.
    - nmin (int): Minimum number of samples required to split a node.
    - minleaf (int): Minimum number of samples required in a leaf.
    - nfeat (int): Number of features to consider when looking for the best split.
    - m (int): Number of trees to grow.

    Returns:
    - list[Node]: List of grown decision trees.
    """
    with Manager() as manager:
        tree_list = manager.list()

        # Use multiprocessing to speed up processing
        p = Pool()
        for i in range(m):
            #
            sample_indices = np.random.choice(np.arange(len(y)), size=len(y), replace=True)
            _x = np.array(x)[sample_indices, :]
            _y = np.array(y)[sample_indices]
            p.apply_async(tree_grow_b_single_tree, args=(_x, _y, nmin, minleaf, nfeat, tree_list, True))
        p.close()
        p.join()

        tree_list = list(tree_list)
        return tree_list


def tree_pred_b(x: list[int], trees: list['Node']):
    """
    Function Name: tree_pred_b

    Predict the class of a sample by using majority predictions from multiple trees.

    Parameters:
    - x (list[int]): Feature vector for a single sample.
    - trees (list[Node]): List of decision trees.

    Returns:
    - int: Predicted class label based on majority vote.
    """
    predict = 0
    for tree in trees:
        predict += tree_pred(x, tree)
    return int((predict / len(trees)) > 0.5)


class Node:
    """
    Class Name: Node

    A class for a tree data structure.

    Attributes:
    - left (Node): Left child of the node (<=).
    - right (Node): Right child of the node (>).
    - is_leaf (bool): Indicates if the node is a leaf.
    - classification (int): Class label for leaf nodes.
    - split_index (int): Feature index used for splitting.
    - split_value (float): Value of the feature used for splitting.
    """

    def __init__(self):
        self.left = None
        self.right = None
        self.is_leaf = False
        self.classification = None
        self.split_index = None
        self.split_value = None

    def set_split(self, split_index: int, split_value: int, left: 'Node', right: 'Node') -> 'Node':
        """
        Function Name: set_split

        Set the node as an internal node with the split criteria.

        Parameters:
        - split_index (int): Index of the feature to split on.
        - split_value (float): Value of the feature to split on.
        - left (Node): Left child after the split.
        - right (Node): Right child after the split.

        Returns:
        - Node: The updated node.
        """
        self.is_leaf = False
        self.left = left
        self.right = right
        self.split_index = split_index
        self.split_value = split_value
        return self

    def set_leaf(self, classification: int) -> 'Node':
        """
        Function Name: set_leaf

        Set the node as a leaf node with the given classification.

        Parameters:
        - classification (int): Class label for this leaf node.

        Returns:
        - Node: The updated node.
        """
        self.is_leaf = True
        self.classification = classification
        return self


def impurity(y: np.ndarray) -> float:
    """
    Function Name: impurity

    Calculate the gini index impurity.

    Parameters:
    - y (np.ndarray): Array of classification values.

    Returns:
    - float: Impurity.
    """
    return np.sum(y == 0) * np.sum(y == 1) / y.shape[0] ** 2


def best_split(x: np.ndarray, y: np.ndarray, minleaf: int) -> (int, int):
    """
    Function Name: best_split

    Find the best feature and value to split the dataset while considering the minleaf constraints.

    Parameters:
    - x (np.ndarray): Feature matrix.
    - y (np.ndarray): Target vector.
    - minleaf (int): Minimum number of samples required in a leaf.

    Returns:
    - tuple: Best split index (feature) and split value.
    """
    if x.shape[0] != y.shape[0]:
        raise ValueError("x and y must have same length")

    max_reduction = -1  # -1 is the lowest possible (not including) value of impurity reduction.
    best_split_index = None
    best_split_value = None
    root_impurity = impurity(y)

    for i in range(x.shape[1]):
        x_column = x[:, i]
        sorted_unique_x = np.sort(np.unique(x_column))
        split_values = (sorted_unique_x[0:-1] + sorted_unique_x[1:]) / 2

        for split_value in split_values:
            y_left = y[x_column <= split_value]
            y_right = y[x_column > split_value]

            if len(y_left) < minleaf or len(y_right) < minleaf:
                continue

            pi_left = len(y_left) / len(y)
            pi_right = 1 - pi_left

            impurity_reduction = root_impurity - (impurity(y_left) * pi_left + impurity(y_right) * pi_right)
            if impurity_reduction > max_reduction:
                max_reduction = impurity_reduction
                best_split_index = i
                best_split_value = split_value

    return best_split_index, best_split_value


def tree_grow_b_single_tree(x, y, nmin: int, minleaf: int, nfeat: int, tree_list, is_root=False) -> 'Node':
    """
    Function Name: tree_grow_b_single_tree

    Grow a single tree for random forest process. Here this funciton is also designed for multiprocessing.

    Parameters:
    - x (np.ndarray): Feature matrix.
    - y (np.ndarray): Target vector.
    - nmin (int): Minimum number of samples required to split a node.
    - minleaf (int): Minimum number of samples required in a leaf.
    - nfeat (int): Number of features to consider when looking for the best split.
    - tree_list (Manager.list): Shared list to store the grown trees.
    - is_root (bool): Whether this is the root call in the parallel execution.

    Returns:
    - Node: The root node of the grown tree.
    """
    _x = x if isinstance(x, np.ndarray) else np.array(x)
    _y = y if isinstance(y, np.ndarray) else np.array(y)

    classification = 1 if np.sum(_y) > len(y) / 2 else 0
    if len(_y) < nmin or impurity(_y) <= 0:
        return Node().set_leaf(classification)

    indices = np.random.choice(np.arange(x.shape[1]), size=nfeat, replace=False)
    best_split_index, best_split_value = best_split(_x[:, indices], _y, minleaf)
    if best_split_index is None:
        return Node().set_leaf(classification)
    best_split_index = indices[best_split_index]
    left_indices = np.where(_x[:, best_split_index] <= best_split_value)[0]
    right_indices = np.where(_x[:, best_split_index] > best_split_value)[0]

    result = Node().set_split(
        best_split_index,
        best_split_value,
        left=tree_grow(_x[left_indices], _y[left_indices], nmin, minleaf, nfeat),
        right=tree_grow(_x[right_indices], _y[right_indices], nmin, minleaf, nfeat),
    )

    if is_root:
        tree_list.append(result)

    return result

